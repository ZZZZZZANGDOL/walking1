# StepRecordMockup

GitHub Actions에서 APK를 자동으로 빌드하는 Android 프로젝트입니다.

## APK 만들기
1. 이 저장소의 **Actions** 탭을 엽니다.
2. **Build APK** workflow를 선택합니다.
3. **Run workflow**를 누릅니다.
4. 실행이 끝나면 해당 실행 페이지의 **Artifacts**에서 `StepRecordMockup-APK`를 다운로드합니다.

앱은 실제 걸음 센서나 건강 데이터와 연동하지 않고, 화면에 지정된 2026년 9월 걸음 기록을 표시합니다.
