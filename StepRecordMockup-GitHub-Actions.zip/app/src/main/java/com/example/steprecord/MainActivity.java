package com.example.steprecord;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    TextView tv(String s,float size,boolean bold){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(Color.rgb(35,38,45)); t.setGravity(Gravity.CENTER_VERTICAL); if(bold)t.setTypeface(null,1); return t; }
    GradientDrawable bg(int c,float r){ GradientDrawable g=new GradientDrawable(); g.setColor(c); g.setCornerRadius(dp(r)); return g; }
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(18),dp(20),dp(18),dp(18)); root.setBackgroundColor(Color.rgb(247,248,252));
        root.addView(tv("걸음 기록",24,true),new LinearLayout.LayoutParams(-1,dp(42)));
        root.addView(tv("2026년 9월",17,true),new LinearLayout.LayoutParams(-1,dp(36)));
        TextView label=tv("5,000보 이상 걸은 날",14,false); label.setTextColor(Color.GRAY); root.addView(label,new LinearLayout.LayoutParams(-1,dp(28)));
        root.addView(tv("20일",58,true),new LinearLayout.LayoutParams(-1,dp(72)));
        LinearLayout stats=new LinearLayout(this); stats.setOrientation(LinearLayout.HORIZONTAL);
        stats.addView(stat("목표 달성률","66.7%","30일 중 20일"),new LinearLayout.LayoutParams(0,dp(92),1));
        Space sp=new Space(this); stats.addView(sp,new LinearLayout.LayoutParams(dp(10),1));
        stats.addView(stat("월 평균","6,184보","9월 1일~30일"),new LinearLayout.LayoutParams(0,dp(92),1)); root.addView(stats);
        TextView daily=tv("일별 기록",16,true); daily.setPadding(0,dp(20),0,dp(8)); root.addView(daily,new LinearLayout.LayoutParams(-1,dp(48)));
        GridLayout grid=new GridLayout(this); grid.setColumnCount(7); grid.setRowCount(6);
        String[] names={"일","월","화","수","목","금","토"};
        for(String n:names){TextView d=tv(n,11,false);d.setGravity(Gravity.CENTER);d.setTextColor(Color.GRAY);grid.addView(d);}
        int[] steps={0,6241,7105,4812,5934,8012,3921,5481,6773,4204,5627,7332,4690,6105,5218,4977,6842,7019,4321,5904,6501,4103,5776,8341,4560,5312,6228,4881,5644,4732,6918};
        Set<Integer> good=new HashSet<>(Arrays.asList(1,2,4,5,7,8,10,11,13,14,16,17,19,20,22,23,25,26,28,30));
        for(int day=1;day<=30;day++){
            TextView d=tv(day+"\n"+String.format("%,d",steps[day]),10,true); d.setGravity(Gravity.CENTER); d.setLineSpacing(0,0.85f);
            d.setTextColor(good.contains(day)?Color.rgb(35,95,70):Color.GRAY);
            d.setBackground(good.contains(day)?bg(Color.rgb(225,244,235),10):bg(Color.WHITE,10));
            GridLayout.LayoutParams lp=new GridLayout.LayoutParams(); lp.width=0; lp.height=dp(52); lp.columnSpec=GridLayout.spec((day+1)%7,1f); lp.setMargins(dp(3),dp(3),dp(3),dp(3)); grid.addView(d,lp);
        }
        root.addView(grid,new LinearLayout.LayoutParams(-1,dp(330)));
        TextView note=tv("5,000보 이상 기록된 날짜가 20일입니다.",12,false); note.setTextColor(Color.GRAY); root.addView(note,new LinearLayout.LayoutParams(-1,dp(40)));
        setContentView(root);
    }
    View stat(String a,String b,String c){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(dp(14),dp(10),dp(10),dp(8)); l.setBackground(bg(Color.WHITE,16)); TextView x=tv(a,11,false);x.setTextColor(Color.GRAY);l.addView(x);l.addView(tv(b,23,true));TextView z=tv(c,10,false);z.setTextColor(Color.GRAY);l.addView(z);return l;}
}